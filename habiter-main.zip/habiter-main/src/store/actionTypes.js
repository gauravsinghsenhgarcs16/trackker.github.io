// creating all the actions varialbles
export const HABIT_ADDED = "habitAdded";
export const HABIT_DELETED = "habitDeleted";
export const STATUS_CHANGED = "statusChanged";
export const UPDATE_HABITS = "updateHabits";
